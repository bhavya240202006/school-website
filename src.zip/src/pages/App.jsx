import React from "react";
import Navbar from "../components/Navbar.jsx";
import { Routes, Route } from "react-router-dom";

import Home from "./Home";
import About from "./About";
import Admission from "./Admission";
import Gallery from "./Gallery";
import Contact from "./Contact";

export default function App() {
  return (
    <>
      <Navbar />
      <h1 style={{ color: "red" }}>APP IS RENDERING</h1>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/admission" element={<Admission />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </>
  );
}
