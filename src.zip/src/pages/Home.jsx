import Navbar from "../components/Navbar.jsx";
  

export default function Home() {
  return (
    <>
      <Navbar />
       
    </>
  );
}
